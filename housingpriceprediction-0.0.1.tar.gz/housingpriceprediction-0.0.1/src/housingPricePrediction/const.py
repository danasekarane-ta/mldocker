LINEAR_MODEL = 'linear'
DECESSION_TREE = 'DecessionTree'
